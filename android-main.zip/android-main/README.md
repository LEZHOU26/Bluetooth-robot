# android

This is an app that connects to another device via Bluetooth. The code found here will eventually be used
to render 3D skeleton joint data from Nuitrack SDK, though there might be other uses for the code that
would require minimal changes.

To compile the Android portion:
Setup Android Studio. Then, import the BluetoothRobot folder as a project, build it, and run it on any Android device running Android 9.0 or higher. 
