package com.example.bluetoothrobot;

import android.content.Context;
import android.view.View;

public class RobotControlView extends View {
    public RobotControlView(Context context){
        super(context);
    }
}
