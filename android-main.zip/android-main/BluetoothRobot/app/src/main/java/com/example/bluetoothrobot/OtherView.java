package com.example.bluetoothrobot;

import android.content.Context;
import android.view.View;

public class OtherView extends View {
    public OtherView(Context context){
        super(context);
    }
}
